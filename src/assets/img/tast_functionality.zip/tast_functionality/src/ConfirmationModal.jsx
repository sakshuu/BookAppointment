import React from 'react';

const ConfirmationModal = ({ show, onClose, onConfirm, appointmentDetails }) => {
  // Check if appointmentDetails.time is a valid Date object
  const isTimeValid = appointmentDetails?.time instanceof Date;

  return (
    <div className={`modal fade ${show ? 'show' : ''}`} tabIndex="-1" role="dialog" style={{ display: show ? 'block' : 'none' }}>
      <div className="modal-dialog" role="document">
        <div className="modal-content">
          <div className="modal-header">
            <h5 className="modal-title">Appointment Confirmation</h5>
            <button type="button" className="close" onClick={onClose} aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div className="modal-body">
            <p>Patient: {appointmentDetails.patient?.name}</p>
            <p>Doctor: {appointmentDetails.doctor?.name}</p>
            <p>Date: {appointmentDetails?.date?.toLocaleDateString()}</p>
            <p>Time: {isTimeValid ? appointmentDetails?.time?.toLocaleTimeString() : 'Invalid Time'}</p>
          </div>
          <div className="modal-footer">
            <button type="button" className="btn btn-secondary" onClick={onClose}>
              Cancel
            </button>
            <button type="button" className="btn btn-primary" onClick={onConfirm}>
              Confirm
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ConfirmationModal;
