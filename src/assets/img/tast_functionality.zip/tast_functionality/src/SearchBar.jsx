import React, { useState } from "react";
import { Form, Dropdown } from "react-bootstrap";

const SearchBar = ({ patients, onPatientSelect }) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [filteredPatients, setFilteredPatients] = useState([]);

  // Function to handle search term change
  const handleSearchChange = (e) => {
    const term = e.target.value;
    setSearchTerm(term);

    // Filter patients based on the search term
    const filtered = patients.filter((patient) =>
      patient.name.toLowerCase().includes(term.toLowerCase())
    );

    setFilteredPatients(filtered);
  };

  // Function to handle patient selection from dropdown
  const handlePatientSelect = (patient) => {
    setSearchTerm(patient.name);
    onPatientSelect(patient);
  };

  return (
    <div>
      <Form.Group controlId="formSearch">
        <Form.Control
          type="text"
          placeholder="Search for patients"
          value={searchTerm}
          onChange={handleSearchChange}
        />
      </Form.Group>

      {/* Display dropdown with patient suggestions */}
      <Dropdown
        className="my-2 d-flex justify-content-center"
        show={filteredPatients.length > 0}
      >
        <Dropdown.Menu>
          {filteredPatients.map((patient) => (
            <Dropdown.Item
              className="mx-5"
              key={patient.id}
              onClick={() => handlePatientSelect(patient)}
            >
              {patient?.name}
            </Dropdown.Item>
          ))}
        </Dropdown.Menu>
      </Dropdown>
    </div>
  );
};

export default SearchBar;
