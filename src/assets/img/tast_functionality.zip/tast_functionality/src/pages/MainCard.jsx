import React from 'react'

export default function MainCard() {

    const cardStyle = {
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
        height : '560px'
        // Adjust the values based on your preference
      };
  return (
    <div className='card me-5 my-3' style={cardStyle}>
       </div>
  )
}
