import React, { useState } from "react";
import SearchBar from "./SearchBar";
import axios from 'axios'
import { Form, Dropdown, Button } from "react-bootstrap"; // Import Button from react-bootstrap
import AppointmentBookingSection from "./AppointmentBookingSection";
import ConfirmationModal from "./ConfirmationModal";

const PatientDetailsSection = ({ selectedPatient }) => {
  return (
    <div className="">
      {selectedPatient && (
        <div>
          <h2>Patient Details</h2>
          <p>Name: {selectedPatient.name}</p>
          <p>condition: {selectedPatient.condition}</p>
          {/* Include other patient details here */}
          {/* <button
            className="btn btn-dark"
            variant="link"
            onClick={() => alert("View more details")}
          >
            View More Details
          </button> */}
        </div>
      )}
    </div>
  );
};

const MainComponent = () => {
  // State to store the selected patient
  const [selectedPatient, setSelectedPatient] = React.useState(null);

  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedTime, setSelectedTime] = useState(null);
  const [showConfirmationModal, setShowConfirmationModal] = useState(false);

  // Updated patient data with additional details

  const patientData = [
    { id: 1, name: "Anir", condition: "Brain" },
    { id: 2, name: "test", condition: "Heart" },
    { id: 3, name: "jay", condition: "Lungs" },
    { id: 4, name: "lara", condition: "Kidney" },
    { id: 5, name: "zoya", condition: "Eyes" },
    { id: 6, name: "Alpha", condition: "Skin" },
    { id: 7, name: "Olivia", condition: "Liver" },
    { id: 8, name: "Karan", condition: "Stomach" },
    { id: 9, name: "bela", condition: "Bones" },
    { id: 10, name: "aayesha", condition: "Muscles" },
    // Add more patient data as needed
  ];
  
  const doctorData = {
    1: {
      name: "Dr. Brainy",
      specialty: "Neurologist",
      availableSlots: ["9:00 AM", "10:00 AM"],
    },
    2: {
      name: "Dr. Heartful",
      specialty: "Cardiologist",
      availableSlots: ["11:00 AM", "1:00 PM"],
    },
    3: {
      name: "Dr. Lungwise",
      specialty: "Pulmonologist",
      availableSlots: ["2:00 PM", "4:00 PM"],
    },
    4: {
      name: "Dr. KidneyCare",
      specialty: "Nephrologist",
      availableSlots: ["10:00 AM", "12:00 PM"],
    },
    5: {
      name: "Dr. EyeExpert",
      specialty: "Ophthalmologist",
      availableSlots: ["3:00 PM", "5:00 PM"],
    },
    6: {
      name: "Dr. SkinCare",
      specialty: "Dermatologist",
      availableSlots: ["11:00 AM", "2:00 PM"],
    },
    7: {
      name: "Dr. LiverDoc",
      specialty: "Hepatologist",
      availableSlots: ["1:00 PM", "3:00 PM"],
    },
    8: {
      name: "Dr. StomachHealer",
      specialty: "Gastroenterologist",
      availableSlots: ["10:00 AM", "11:30 AM"],
    },
    9: {
      name: "Dr. BoneDoctor",
      specialty: "Orthopedist",
      availableSlots: ["9:30 AM", "12:30 PM"],
    },
    10: {
      name: "Dr. MuscleTherapist",
      specialty: "Rheumatologist",
      availableSlots: ["2:30 PM", "4:30 PM"],
    },

  };
  const handlePatientSelect = (patient) => {
    setSelectedPatient(patient);
  };

  // ... (Previous code)

  const DoctorDetailsSection = ({ selectedPatient, doctorData }) => {
    const selectedDoctor = selectedPatient
      ? doctorData[selectedPatient.id]
      : null;

    return (
      <div>
        {selectedDoctor && (
          <div>
            <h2>Doctor Details</h2>
            <p>Name: {selectedDoctor.name}</p>
            <p>Specialty: {selectedDoctor.specialty}</p>
            <p>Available Slots: {selectedDoctor.availableSlots.join(", ")}</p>
            {/* Include other doctor details here */}
          </div>
        )}
      </div>
    );
  };

  const handleConfirmAppointment = () => {
    // Implement logic to submit the appointment or perform other actions
    // For now, just toggle the modal state
    setShowConfirmationModal(!showConfirmationModal);
  };

 const getData = async () => {

  const result = await axios.get("url")
return result.data
  
 }

 useEffect( async () => {
  const data = await getData()
  setallData(data)

 }, [])
 


  return (
    <div className="container my-5">
      <h1>Appointment System</h1>
      {/* Include other components as needed */}
      {/* Search Bar for Patients */}
      <SearchBar patients={patientData} onPatientSelect={handlePatientSelect} />
      <br />
      {/* Patient Details Section */}
    {selectedPatient && <PatientDetailsSection selectedPatient={selectedPatient} />}  
      {/* Doctor Details Section */}
    {  selectedPatient &&  <DoctorDetailsSection
        selectedPatient={selectedPatient}
        doctorData={doctorData}
      />}
      {/* Appointment Booking Section */}
  {    selectedPatient &&    <AppointmentBookingSection
        onSelectDate={(date) => setSelectedDate(date)}
        onSelectTime={(time) => setSelectedTime(time)}
      />}
      {/* Confirmation Modal */}
    
      {/* Confirmation Modal */}
      <ConfirmationModal
        show={showConfirmationModal}
        onClose={() => setShowConfirmationModal(false)}
        onConfirm={handleConfirmAppointment}
        appointmentDetails={{
          patient: selectedPatient,
          doctor: doctorData[selectedPatient?.id],
          date: selectedDate,
          time: selectedTime,
        }}
      />
      {/* Include other components as needed */}
    </div>
  );
};

export default MainComponent;
