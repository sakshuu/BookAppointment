import React from 'react'
import MainComponent from './MainComponent'
import Sidebar from './components/Sidebar'

export default function App() {
  return (
    <div>
    <MainComponent/>
    {/* <Sidebar/> */}
    
    </div>
  )
}
