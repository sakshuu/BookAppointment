import React from "react";
import MainCard from "../pages/MainCard";

const Sidebar = () => {
  return (
    <div className="container-fluid">
      <div className="row flex-nowrap">
        <div className="col-auto col-md-3  col-xl-2 px-sm-2 px-0 bg-white ">
          <div className="d-flex flex-column align-items-center align-items-sm-start px-3 pt-2 text-white min-vh-100">
            <a
              href="/"
              className="d-flex align-items-center pb-3 mb-md-0 me-md-auto mt-3 text-dark text-decoration-none"
            >
              <strong className=" d-none d-sm-inline text-primary">
                {" "}
                <i class="bi bi-file-text mx-2"></i> Dashboard
              </strong>
            </a>
            <a
              href="/"
              className="d-flex align-items-center pb-3 mb-md-0 me-md-auto text-dark text-decoration-none"
            >
              <strong className=" d-none d-sm-inline">
                {" "}
                <i class="bi bi-calendar3 mx-2"></i> Appointments
              </strong>
            </a>
            <a
              href="/"
              className="d-flex align-items-center pb-3 mb-md-0 me-md-auto text-dark text-decoration-none"
            >
              <strong className=" d-none d-sm-inline">
                {" "}
                <i class="bi bi-people-fill mx-2"></i> Patients
              </strong>
            </a>
            <a
              href="/"
              className="d-flex align-items-center pb-3 mb-md-0 me-md-auto text-dark text-decoration-none"
            >
              <strong className=" d-none d-sm-inline">
                {" "}
                <i class="bi bi-chat-dots-fill mx-2"></i> Messaging
              </strong>
            </a>
            <a
              href="/"
              className="d-flex align-items-center pb-3 mb-md-0 me-md-auto text-dark text-decoration-none"
            >
              <strong className=" d-none d-sm-inline">
                {" "}
                <i class="bi bi-person-lines-fill mx-2"></i> Profile
              </strong>
            </a>
            <ul
              className="nav nav-pills flex-column mb-sm-auto mb-0 align-items-center align-items-sm-start"
              id="menu"
            ></ul>
            <hr />
            <div className="dropdown pb-4">
              <a
                href="/"
                className="d-flex align-items-center pb-3 mb-md-0 me-md-auto text-dark text-decoration-none"
              >
                <strong className=" d-none d-sm-inline">
                  {" "}
                  <i class="bi bi-gear-fill mx-2"></i>Setting
                </strong>
              </a>
              <a
                href="/"
                className="d-flex align-items-center pb-3 mb-md-0 me-md-auto text-dark text-decoration-none"
              >
                <strong className=" d-none d-sm-inline">
                  {" "}
                  <i class="bi bi-box-arrow-right mx-2 text-danger"></i>Logout
                </strong>
              </a>
            </div>
          </div>
        </div>
        <div className="col py-4">
          <h3>
            <strong>Book Appointments</strong>
          </h3>
          <MainCard />
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
