import React, { useState } from 'react';
import { Form, Dropdown, Button } from 'react-bootstrap';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';

 const AppointmentBookingSection = ({ onSelectDate, onSelectTime }) => {
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedTime, setSelectedTime] = useState(null);

  const handleDateChange = (date) => {
    setSelectedDate(date);
    onSelectDate(date);
  };

  const handleTimeChange = (e) => {
    const time = e.target.value;
    setSelectedTime(time);
    onSelectTime(time);
  };

  return (
    <div>
      <h2>Appointment Booking</h2>
      <Form.Group controlId="formDate">
        <Form.Label>Choose Date:</Form.Label>
        <br />
        <DatePicker selected={selectedDate} onChange={handleDateChange} dateFormat="MMMM d, yyyy" />
      </Form.Group>

      <Form.Group controlId="formTime">
        <Form.Label>Choose Time:</Form.Label>
        <br />
        <Form.Control as="select" onChange={handleTimeChange}>
          <option value="9:00 AM">9:00 AM</option>
          <option value="10:00 AM">10:00 AM</option>
          <option value="11:00 AM">11:00 AM</option>
          <option value="1:00 PM">1:00 PM</option>
          {/* Add more time options as needed */}
        </Form.Control>
      </Form.Group>
    </div>
  );
};

export default AppointmentBookingSection;
