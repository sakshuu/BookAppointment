import React from 'react';
import "./assets/css/index.css"
import { Home } from './pages';

const App = () => {

  return (<>
 <Home/> 
  </>
  );
};

export default App;


