export {default as doctor } from "./doctor.avif"
export {default as avatar} from "./avatar.jpg"